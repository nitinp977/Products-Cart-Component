import "./App.css";
import Papp from "./components/ProducsPage";
import Footer from './components/Footer';

function App() {
  return (
    <div>
      <Papp/>
      <Footer/>
    </div>
  );
}

export default App;