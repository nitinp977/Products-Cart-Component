import React from "react";
import "./styleFooter.css";

export default function Footer() {
  return (
    <div className="footer-main">
      <div className="container">
        <div style={{display:'flex',padding:'5px 20px',justifyContent:'space-evenly'}}>
          {/* Column1 */}
          <div className="col">
            <h4>COMPANY</h4>
            <ui className="list-unstyled">
              <li>About us</li>
              <li>Our Services</li>
              <li>Privacy Policies</li>
            </ui>
          </div>
          {/* Column2 */}
          <div className="col">
            <h4>ONLINE SHOPPING</h4>
            <ui className="list-unstyled">
              <li>LAPTOPS</li>
              <li>WATCHES</li>
              <li>MOBILES</li>
              <li>ELECTRONIC GADGETS</li>
              <li></li>
            </ui>
          </div>
          {/* Column3 */}
          <div className="col">
            <h4>GET HELP</h4>
            <ui className="list-unstyled">
              <li>FAQ</li>
              <li>SHIPPING</li>
              <li>RETURNS</li>
              <li>PAYMENT OPTIONS</li>
            </ui>
          </div>
          <div className="col">
            <h4>FOLLOW US</h4>
            <ui className="list-unstyled">
              <a className="footer-a" href="https://twitter.com/" target="_blank" rel="noreferrer">
                Twitter
              </a>
              <br />
              <a className="footer-a" href="https://facebook.com/" target="_blank" rel="noreferrer">
                Facebook
              </a>
              <br />
              <a className="footer-a" href="https://instagram.com/" target="_blank" rel="noreferrer">
                Instagram
              </a>
              <br />
            </ui>
          </div>
        </div>
        <hr />
        <div className="row">
          <p className="col-sm">
            &copy;{new Date().getFullYear()} | All rights reserved | Terms Of
            Service | Privacy
          </p>
        </div>
      </div>
    </div>
  );
}
